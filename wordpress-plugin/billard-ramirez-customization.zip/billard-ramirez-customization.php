<?php
/**
 * Plugin Name: Billard Ramirez - Personalización de Tacos
 * Plugin URI: https://billardramirez.cl
 * Description: Gestiona la personalización de tacos con grabado láser y guarda metadata en pedidos de WooCommerce
 * Version: 1.0.0
 * Author: Billard Ramirez
 * Author URI: https://billardramirez.cl
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 5.0
 * WC tested up to: 8.0
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Clase principal del plugin de personalización
 */
class Billard_Ramirez_Customization {

    /**
     * Opción para guardar el precio del grabado láser
     */
    const OPTION_LASER_PRICE = 'billard_ramirez_laser_engraving_price';

    /**
     * Constructor
     */
    public function __construct() {
        // Hooks de admin
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);

        // Registrar endpoint REST API
        add_action('rest_api_init', [$this, 'register_rest_routes']);

        // Hooks de WooCommerce para metadata
        add_action('woocommerce_add_cart_item_data', [$this, 'add_cart_item_data'], 10, 3);
        add_filter('woocommerce_get_item_data', [$this, 'display_cart_item_data'], 10, 2);
        add_action('woocommerce_checkout_create_order_line_item', [$this, 'save_order_item_meta'], 10, 4);
        add_action('woocommerce_before_calculate_totals', [$this, 'add_custom_price'], 10, 1);
    }

    /**
     * Agregar página de administración
     */
    public function add_admin_menu() {
        add_submenu_page(
            'woocommerce',
            'Personalización de Tacos',
            'Personalización Tacos',
            'manage_woocommerce',
            'billard-customization',
            [$this, 'render_admin_page']
        );
    }

    /**
     * Registrar configuraciones
     */
    public function register_settings() {
        register_setting('billard_customization_settings', self::OPTION_LASER_PRICE, [
            'type' => 'number',
            'default' => 10000,
            'sanitize_callback' => 'absint'
        ]);

        add_settings_section(
            'billard_customization_main',
            'Configuración de Personalización',
            [$this, 'settings_section_callback'],
            'billard-customization'
        );

        add_settings_field(
            'laser_engraving_price',
            'Precio Grabado Láser (CLP)',
            [$this, 'laser_price_field_callback'],
            'billard-customization',
            'billard_customization_main'
        );
    }

    /**
     * Renderizar página de administración
     */
    public function render_admin_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

            <div class="notice notice-info">
                <p><strong>Instrucciones:</strong> Configure aquí el precio del grabado láser para los tacos. Este valor será utilizado automáticamente por el frontend.</p>
            </div>

            <form method="post" action="options.php">
                <?php
                settings_fields('billard_customization_settings');
                do_settings_sections('billard-customization');
                submit_button('Guardar Configuración');
                ?>
            </form>

            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2>Información del Plugin</h2>
                <p>Este plugin gestiona la personalización de tacos con las siguientes características:</p>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <li>Precio configurable del grabado láser</li>
                    <li>API REST para obtener el precio desde el frontend</li>
                    <li>Guardado automático de metadata en pedidos de WooCommerce</li>
                    <li>Visualización de personalización en carrito y pedidos</li>
                </ul>

                <h3>Endpoint API</h3>
                <p><code>GET <?php echo esc_url(rest_url('billard/v1/customization/laser-price')); ?></code></p>
                <p>Respuesta: <code>{"price": 10000, "formatted": "$10.000"}</code></p>
            </div>
        </div>
        <?php
    }

    /**
     * Callback para sección de configuración
     */
    public function settings_section_callback() {
        echo '<p>Configure los precios y opciones de personalización para los productos.</p>';
    }

    /**
     * Callback para campo de precio del grabado láser
     */
    public function laser_price_field_callback() {
        $value = get_option(self::OPTION_LASER_PRICE, 10000);
        ?>
        <input
            type="number"
            name="<?php echo esc_attr(self::OPTION_LASER_PRICE); ?>"
            value="<?php echo esc_attr($value); ?>"
            min="0"
            step="100"
            class="regular-text"
        />
        <p class="description">Precio en pesos chilenos (CLP) para el servicio de grabado láser en tacos.</p>
        <?php
    }

    /**
     * Registrar rutas REST API
     */
    public function register_rest_routes() {
        register_rest_route('billard/v1', '/customization/laser-price', [
            'methods' => 'GET',
            'callback' => [$this, 'get_laser_price'],
            'permission_callback' => '__return_true'
        ]);
    }

    /**
     * Obtener precio del grabado láser via API
     */
    public function get_laser_price() {
        $price = get_option(self::OPTION_LASER_PRICE, 10000);

        return [
            'price' => intval($price),
            'formatted' => '$' . number_format($price, 0, ',', '.')
        ];
    }

    /**
     * Agregar datos personalizados al item del carrito
     */
    public function add_cart_item_data($cart_item_data, $product_id, $variation_id) {
        // Verificar si hay datos de personalización en la petición
        if (isset($_POST['customization'])) {
            $customization = json_decode(stripslashes($_POST['customization']), true);

            if (isset($customization['laserEngraving']) && $customization['laserEngraving']['enabled']) {
                $cart_item_data['laser_engraving'] = [
                    'text' => sanitize_text_field($customization['laserEngraving']['text']),
                    'price' => intval($customization['laserEngraving']['price'])
                ];

                // Hacer el item único para que no se agrupe con otros
                $cart_item_data['unique_key'] = md5(microtime() . rand());
            }
        }

        return $cart_item_data;
    }

    /**
     * Mostrar datos personalizados en el carrito
     */
    public function display_cart_item_data($item_data, $cart_item) {
        if (isset($cart_item['laser_engraving'])) {
            $item_data[] = [
                'key' => 'Grabado Láser',
                'value' => '"' . esc_html($cart_item['laser_engraving']['text']) . '" (+$' . number_format($cart_item['laser_engraving']['price'], 0, ',', '.') . ')',
                'display' => ''
            ];
        }

        return $item_data;
    }

    /**
     * Agregar precio personalizado al producto en el carrito
     */
    public function add_custom_price($cart) {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            if (isset($cart_item['laser_engraving'])) {
                $product = $cart_item['data'];
                $original_price = floatval($product->get_price());
                $laser_price = floatval($cart_item['laser_engraving']['price']);
                $new_price = $original_price + $laser_price;

                $product->set_price($new_price);
            }
        }
    }

    /**
     * Guardar metadata personalizada en el item del pedido
     */
    public function save_order_item_meta($item, $cart_item_key, $values, $order) {
        if (isset($values['laser_engraving'])) {
            $item->add_meta_data('Grabado Láser', $values['laser_engraving']['text'], true);
            $item->add_meta_data('_laser_engraving_text', $values['laser_engraving']['text'], false);
            $item->add_meta_data('_laser_engraving_price', $values['laser_engraving']['price'], false);
        }
    }
}

// Inicializar el plugin
function billard_ramirez_customization_init() {
    // Verificar que WooCommerce esté activo
    if (class_exists('WooCommerce')) {
        new Billard_Ramirez_Customization();
    } else {
        add_action('admin_notices', function() {
            ?>
            <div class="notice notice-error">
                <p><strong>Billard Ramirez Personalización:</strong> Este plugin requiere que WooCommerce esté instalado y activado.</p>
            </div>
            <?php
        });
    }
}

add_action('plugins_loaded', 'billard_ramirez_customization_init');
